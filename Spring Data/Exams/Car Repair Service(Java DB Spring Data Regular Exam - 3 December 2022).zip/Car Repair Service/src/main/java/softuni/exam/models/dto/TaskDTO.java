package softuni.exam.models.dto;

import org.springframework.format.annotation.DateTimeFormat;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import java.math.BigDecimal;

@XmlAccessorType(XmlAccessType.FIELD)
public class TaskDTO {
    @XmlElement
    private String date;
    @XmlElement
    private BigDecimal price;
    @XmlElement
    private CarDTO car;
    @XmlElement
    private MechanicDTO mechanic;
    @XmlElement
    private PartDTO part;

    public TaskDTO() {
    }

    @NotNull
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @NotNull
    @Positive
    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }
    @NotNull
    public CarDTO getCar() {
        return car;
    }

    public void setCar(CarDTO car) {
        this.car = car;
    }
    @NotNull
    public MechanicDTO getMechanic() {
        return mechanic;
    }

    public void setMechanic(MechanicDTO mechanic) {
        this.mechanic = mechanic;
    }
    @NotNull
    public PartDTO getPart() {
        return part;
    }

    public void setPart(PartDTO part) {
        this.part = part;
    }

    //Може и без тези методи, но ще ги оставя тук за всеки случай, ако потрябват на някого за нещо! :D
//    public BigDecimal getPriceAsBigDecimal() {
//        return new BigDecimal(price);
//    }
//
//    public void setPriceAsBigDecimal(BigDecimal price) {
//        this.price = price.toString();
//    }

}
