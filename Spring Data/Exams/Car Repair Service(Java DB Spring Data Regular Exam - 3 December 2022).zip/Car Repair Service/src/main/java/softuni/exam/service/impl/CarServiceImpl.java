package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.CarSeedRootDTO;
import softuni.exam.models.entity.Car;
import softuni.exam.repository.CarRepository;
import softuni.exam.service.CarService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class CarServiceImpl implements CarService {
    private static final String CARS_FILE_PATH = "src/main/resources/files/xml/cars.xml";
    private static final String SUCCESSFUL_MESSAGE = "Successfully imported car %s - %s";
    private static final String NOT_SUCCESSFUL_MESSAGE = "Invalid car";

    private final CarRepository carRepository;
    private final XmlParser xmlParser;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;

    @Autowired
    public CarServiceImpl(CarRepository carRepository, XmlParser xmlParser, ModelMapper modelMapper, ValidationUtil validationUtil) {
        this.carRepository = carRepository;
        this.xmlParser = xmlParser;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
    }

    @Override
    public boolean areImported() {
        return this.carRepository.count() > 0;
    }

    @Override
    public String readCarsFromFile() throws IOException {
        return Files.readString(Path.of(CARS_FILE_PATH));
    }

    @Override
    public String importCars() throws IOException, JAXBException {
        StringBuilder resultInfo = new StringBuilder();
        CarSeedRootDTO dtos = this.xmlParser.parseXml(CarSeedRootDTO.class, CARS_FILE_PATH);

        dtos.getCars()
                .forEach(dto -> {
                    if (this.validationUtil.isValid(dto)) {
                        if (this.carRepository.findByPlateNumber(dto.getPlateNumber()) != null) {
                         resultInfo.append(NOT_SUCCESSFUL_MESSAGE);
                        } else {
                            Car car = this.modelMapper
                                    .map(dto, Car.class);
                            resultInfo.append(String.format(SUCCESSFUL_MESSAGE, dto.getCarMake(), dto.getCarModel()));
                            this.carRepository.saveAndFlush(car);
                        }
                    } else {
                        resultInfo.append(NOT_SUCCESSFUL_MESSAGE);
                    }
                    resultInfo.append(System.lineSeparator());
                });

        return resultInfo.toString().trim();
    }

    @Override
    public Car getCarById(Long id) {
        return this.carRepository.findById(id).orElse(null);
    }
}
