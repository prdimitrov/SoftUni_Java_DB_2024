package softuni.exam.models.dto;

import softuni.exam.models.entity.CarType;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class CarSeedDTO {
    @XmlElement
    private String carMake;
    @XmlElement
    private String carModel;
    @XmlElement
    private int year;
    @XmlElement
    private String plateNumber;
    @XmlElement
    private int kilometers;
    @XmlElement
    private double engine;
    @XmlElement
    private CarType carType;

    public CarSeedDTO() {
    }

    @NotNull
    @Size(min = 2, max = 30)
    public String getCarMake() {
        return carMake;
    }

    @NotNull
    @Size(min = 2, max = 30)
    public String getCarModel() {
        return carModel;
    }

    @NotNull
    @Positive
    public int getYear() {
        return year;
    }

    @NotNull
    @Size(min = 2, max = 30)
    public String getPlateNumber() {
        return plateNumber;
    }

    @NotNull
    @DecimalMin(value = "1.00")
    public double getEngine() {
        return engine;
    }

    @NotNull
    public CarType getCarType() {
        return carType;
    }

    @NotNull
    @Positive
    public int getKilometers() {
        return kilometers;
    }
}
