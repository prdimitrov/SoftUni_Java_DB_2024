package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.MechanicSeedDTO;
import softuni.exam.models.entity.Mechanic;
import softuni.exam.repository.MechanicRepository;
import softuni.exam.service.MechanicService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

// TODO: Implement all methods
@Service
public class MechanicServiceImpl implements MechanicService {
    private static final String MECHANIC_FILE_PATH = "src/main/resources/files/json/mechanics.json";
    private static final String SUCCESSFUL_MESSAGE = "Successfully imported mechanic %s %s";
    private static final String NOT_SUCCESSFUL_MESSAGE = "Invalid mechanic";


    private final MechanicRepository mechanicRepository;
    private final Gson gson;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public MechanicServiceImpl(MechanicRepository mechanicRepository, Gson gson, ValidationUtil validationUtil, ModelMapper modelMapper) {
        this.mechanicRepository = mechanicRepository;
        this.gson = gson;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public boolean areImported() {
        return this.mechanicRepository.count() > 0;
    }

    @Override
    public String readMechanicsFromFile() throws IOException {
        return Files.readString(Path.of(MECHANIC_FILE_PATH));
    }

    @Override
    public String importMechanics() throws IOException {
        StringBuilder resultInfo = new StringBuilder();
        //•	If the mechanic with the same email already exists in the DB return "Invalid mechanic".
        MechanicSeedDTO[] dtos = this.gson
                .fromJson(readMechanicsFromFile(), MechanicSeedDTO[].class);

        Arrays.stream(dtos)
                .forEach(dto -> {
                    if (this.validationUtil.isValid(dto)) {
                        if (this.mechanicRepository.findByEmail(dto.getEmail()) != null) {
                            resultInfo.append(NOT_SUCCESSFUL_MESSAGE);
                        } else {
                            Mechanic mechanic = this.modelMapper
                                    .map(dto, Mechanic.class);
                            resultInfo.append(String.format(SUCCESSFUL_MESSAGE, dto.getFirstName(), dto.getLastName()));
                            this.mechanicRepository.saveAndFlush(mechanic);
                        }
                    } else {
                        resultInfo.append(NOT_SUCCESSFUL_MESSAGE);
                    }
                    resultInfo.append(System.lineSeparator());
                });

        return resultInfo.toString().trim();
    }

    @Override
    public Mechanic getMechanicByFirstName(String firstName) {
        return this.mechanicRepository.findByFirstName(firstName);
    }
}
