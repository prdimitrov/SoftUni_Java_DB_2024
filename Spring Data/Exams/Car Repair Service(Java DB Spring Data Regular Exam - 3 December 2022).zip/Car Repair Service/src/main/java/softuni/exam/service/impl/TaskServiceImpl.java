package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.TaskOutputDTO;
import softuni.exam.models.dto.TaskSeedRootDTO;
import softuni.exam.models.entity.CarType;
import softuni.exam.models.entity.Task;
import softuni.exam.repository.TaskRepository;
import softuni.exam.service.CarService;
import softuni.exam.service.MechanicService;
import softuni.exam.service.PartService;
import softuni.exam.service.TaskService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;

// TODO: Implement all methods
@Service
public class TaskServiceImpl implements TaskService {
    private static final String TASKS_FILE_PATH = "src/main/resources/files/xml/tasks.xml";
    private static final String SUCCESSFUL_MESSAGE = "Successfully imported task %.2f";
    private static final String NOT_SUCCESSFUL_MESSAGE = "Invalid task";
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final TaskRepository taskRepository;
    private final XmlParser xmlParser;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;
    private final CarService carService;
    private final PartService partService;
    private final MechanicService mechanicService;

    @Autowired
    public TaskServiceImpl(TaskRepository taskRepository, XmlParser xmlParser, ValidationUtil validationUtil, ModelMapper modelMapper, CarService carService, PartService partService, MechanicService mechanicService) {
        this.taskRepository = taskRepository;
        this.xmlParser = xmlParser;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
        this.carService = carService;
        this.partService = partService;
        this.mechanicService = mechanicService;
    }


    @Override
    public boolean areImported() {
        return this.taskRepository.count() > 0;
    }

    @Override
    public String readTasksFileContent() throws IOException {
        return Files.readString(Path.of(TASKS_FILE_PATH));
    }

    @Override
    public String importTasks() throws IOException, JAXBException {
        StringBuilder resultInfo = new StringBuilder();
        TaskSeedRootDTO dtos = this.xmlParser
                .parseXml(TaskSeedRootDTO.class, TASKS_FILE_PATH);
        dtos.getTask()
                .forEach(dto -> {
                 if (this.validationUtil.isValid(dto)) {
                     String mechanicDtoFirstName = dto.getMechanic().getFirstName();
                     if (this.mechanicService.getMechanicByFirstName(mechanicDtoFirstName) == null) {
                         resultInfo.append(NOT_SUCCESSFUL_MESSAGE);
                     } else {
                         Task task = this.modelMapper
                                 .map(dto, Task.class);
                         task.setCar(this.carService.getCarById(dto.getCar().getId()));
                         task.setMechanic(this.mechanicService.getMechanicByFirstName(dto.getMechanic().getFirstName()));
                         task.setPart(this.partService.getPartById(dto.getPart().getId()));
                         LocalDateTime date = LocalDateTime.parse(dto.getDate(), DATE_TIME_FORMATTER);
                         task.setDate(date);
                         //TODO: Очевидно взимам 0/100 точки на Import задачата, незнайно защо, всичко изглежда наред според мен.
                         resultInfo.append(String.format(SUCCESSFUL_MESSAGE, dto.getPrice().doubleValue()));
                         this.taskRepository.saveAndFlush(task);
                     }

                 } else {
                     resultInfo.append(NOT_SUCCESSFUL_MESSAGE);
                 }
                 resultInfo.append(System.lineSeparator());
                });

        return resultInfo.toString().trim();
    }

    @Override
    public String getCoupeCarTasksOrderByPrice() {
        StringBuilder results = new StringBuilder();
        /*
        •	Extract from the database, the car's make, car's model, mechanic's first name, mechanic's last name, task id, engine, task price (to the second digit after the decimal point) of the task.
        •	Filter only coupe cars and order them by the price in descending order.
        •	Return the information in this format:
"Car {carMake} {carModel} with {kilometers}km
         -Mechanic: {firstName} {lastName} - task №{taskId}:¬¬
         --Engine: {engine}
         ---Price: {taskPrice}$
. . ."
         */
        List<Task> taskList = this.taskRepository.findAll();

        // Process the fetched data and format the results
        taskList.stream()
                .filter(task -> task.getCar().getCarType().toString().equals("coupe"))
                .sorted(Comparator.comparing(Task::getPrice).reversed())
                .forEach(task -> {
                    // Append formatted information to the results StringBuilder
                    results.append(String.format("Car %s %s with %dkm%n",
                            task.getCar().getCarMake(), task.getCar().getCarModel(), task.getCar().getKilometers()));
                    results.append(String.format("-Mechanic: %s %s - task №%d:%n",
                            task.getMechanic().getFirstName(), task.getMechanic().getLastName(), task.getId()));
                    results.append(String.format("--Engine: %s%n", task.getCar().getEngine()));
                    results.append(String.format("---Price: %.2f$%n", task.getPrice()));
                    results.append(System.lineSeparator());
                });
        return results.toString().trim();
    }
}
