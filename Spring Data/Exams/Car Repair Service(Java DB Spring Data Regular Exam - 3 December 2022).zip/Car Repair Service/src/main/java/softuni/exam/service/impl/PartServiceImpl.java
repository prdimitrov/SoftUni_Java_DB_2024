package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.PartSeedDTO;
import softuni.exam.models.entity.Part;
import softuni.exam.repository.PartRepository;
import softuni.exam.service.PartService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

@Service
public class PartServiceImpl implements PartService {
    private static final String PARTS_FILE_PATH = "src/main/resources/files/json/parts.json";

    private final PartRepository partRepository;
    private final Gson gson;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public PartServiceImpl(PartRepository partRepository, Gson gson, ValidationUtil validationUtil, ModelMapper modelMapper) {
        this.partRepository = partRepository;
        this.gson = gson;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public boolean areImported() {
        return this.partRepository.count() > 0;
    }


    @Override
    public String readPartsFileContent() throws IOException {
        return Files.readString(Path.of(PARTS_FILE_PATH));
    }

    @Override
    public String importParts() throws IOException {
        StringBuilder resultInfo = new StringBuilder();
        PartSeedDTO[] dtos = this.gson.fromJson(readPartsFileContent(), PartSeedDTO[].class);

        Arrays.stream(dtos)
                .forEach(dto -> {
                    if (this.validationUtil.isValid(dto)) {
                        if (this.partRepository.findByPartName(dto.getPartName()) == null) {
                            //TODO: ИМА ГРЕШКА ТУК ПРИ ДОБАВЯНЕТО, ВИЖ където имаш 2 пъти Alternator, Не трябва
                            //да се добавят 2, само първия, нещо има проблем там!
                            Part part = this.modelMapper.map(dto, Part.class);

                            this.partRepository.saveAndFlush(part);
                            //Successfully imported part (getPartName) - (getPrice)
                            resultInfo.append("Successfully imported part ")
                                    .append(dto.getPartName())
                                    .append(" - ")
                                    .append(dto.getPrice());
                        } else {
                            resultInfo.append("Invalid part");
                        }
                    } else {
                        resultInfo.append("Invalid part");
                    }
                    resultInfo.append(System.lineSeparator());
                });
        return resultInfo.toString().trim();
    }

    @Override
    public Part getPartById(Long id) {
        return this.partRepository.findById(id).orElse(null);
    }

}
