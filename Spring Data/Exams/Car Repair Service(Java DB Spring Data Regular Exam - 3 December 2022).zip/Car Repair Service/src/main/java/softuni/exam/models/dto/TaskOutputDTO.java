package softuni.exam.models.dto;

import java.math.BigDecimal;

public class TaskOutputDTO {
    private String carMake;
    private String carModel;
    private int kilometers;
    private String mechanicFirstName;
    private String mechanicLastName;
    private Long taskId;
    private String engine;
    private BigDecimal taskPrice;

    public TaskOutputDTO() {
    }

    public String getCarMake() {
        return carMake;
    }

    public String getCarModel() {
        return carModel;
    }

    public int getKilometers() {
        return kilometers;
    }

    public String getMechanicFirstName() {
        return mechanicFirstName;
    }

    public String getMechanicLastName() {
        return mechanicLastName;
    }

    public Long getTaskId() {
        return taskId;
    }

    public String getEngine() {
        return engine;
    }

    public BigDecimal getTaskPrice() {
        return taskPrice;
    }
}
