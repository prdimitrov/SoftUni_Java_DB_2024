package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.CityImportDTO;
import softuni.exam.models.entity.City;
import softuni.exam.models.entity.Country;
import softuni.exam.repository.CityRepository;
import softuni.exam.service.CityService;
import softuni.exam.service.CountryService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

@Service
public class CityServiceImpl implements CityService {
    private static final String CITIES_FILE_PATH = "src/main/resources/files/json/cities.json";
    private final CityRepository cityRepository;
    private final Gson gson;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final CountryService countryService;

    @Autowired
    public CityServiceImpl(CityRepository cityRepository, Gson gson, ModelMapper modelMapper, ValidationUtil validationUtil, CountryService countryService) {
        this.cityRepository = cityRepository;
        this.gson = gson;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.countryService = countryService;
    }

    @Override
    public boolean areImported() {
        return this.cityRepository.count() > 0;
    }

    @Override
    public String importCities() throws IOException {
        StringBuilder resultInfo = new StringBuilder();
        CityImportDTO[] dtos = this.gson
                .fromJson(readCitiesFileContent(), CityImportDTO[].class);

        Arrays.stream(dtos)
                .forEach(dto -> {
                    if (this.validationUtil.isValid(dto)) {
                        if (this.cityRepository.findByCityName(dto.getCityName()) == null) {
                            City city = this.modelMapper
                                    .map(dto, City.class);
                            Country country = this.countryService.getCountryById(dto.getCountry());
                            city.setCountry(country);

                            resultInfo.append("Successfully imported city ")
                                    .append(dto.getCityName())
                                    .append(" - ")
                                    .append(dto.getPopulation());
                            this.cityRepository.saveAndFlush(city);
                        } else {
                            resultInfo.append("Invalid city");
                        }

                    } else {
                        resultInfo.append("Invalid city");
                    }
                    resultInfo.append(System.lineSeparator());
                });

        return resultInfo.toString().trim();
    }

    @Override
    public City getCityById(Long id) {
        return this.cityRepository.findById(id).orElse(null);
    }

    @Override
    public String readCitiesFileContent() throws IOException {
        return Files.readString(Path.of(CITIES_FILE_PATH));
    }
}
