package softuni.exam.models.entity;

public enum DayOfTheWeek {
FRIDAY, SATURDAY, SUNDAY
}
