package softuni.exam.models.dto;

import com.google.gson.annotations.Expose;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

public class CityImportDTO {
    @Expose
    private String cityName;
    @Expose
    private String description;
    @Expose
    private int population;
    @Expose
    private Long country;

    public CityImportDTO() {
    }

    @NotNull
    @Size(min = 2, max = 60)
    public String getCityName() {
        return cityName;
    }

    @Size(min = 2)
    public String getDescription() {
        return description;
    }

    @NotNull
    @Min(500)
    public int getPopulation() {
        return population;
    }

    @NotNull
    @Positive
    public Long getCountry() {
        return country;
    }
}
