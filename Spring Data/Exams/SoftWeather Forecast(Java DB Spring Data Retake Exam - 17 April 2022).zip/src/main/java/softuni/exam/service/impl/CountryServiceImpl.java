package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.CountryImportDTO;
import softuni.exam.models.entity.Country;
import softuni.exam.repository.CountryRepository;
import softuni.exam.service.CountryService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

@Service
public class CountryServiceImpl implements CountryService {
    private static final String COUNTRIES_FILE_PATH = "src/main/resources/files/json/countries.json";
    private final CountryRepository countryRepository;
    private final Gson gson;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;

    @Autowired
    public CountryServiceImpl(CountryRepository countryRepository, Gson gson, ModelMapper modelMapper, ValidationUtil validationUtil) {
        this.countryRepository = countryRepository;
        this.gson = gson;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
    }

    @Override
    public boolean areImported() {
        return this.countryRepository.count() > 0;
    }

    @Override
    public String readCountriesFromFile() throws IOException {
        return Files.readString(Path.of(COUNTRIES_FILE_PATH));
    }

    @Override
    public String importCountries() throws IOException {
        StringBuilder resultInfo = new StringBuilder();
        CountryImportDTO[] dtos = this.gson
                .fromJson(readCountriesFromFile(), CountryImportDTO[].class);

        Arrays.stream(dtos)
                .forEach(dto -> {
                    if (this.validationUtil.isValid(dto)) {
                        if (this.countryRepository.findByCountryName(dto.getCountryName()) == null) {
                            Country country = this.modelMapper.map(dto, Country.class);

                            resultInfo.append("Successfully imported country ")
                                    .append(dto.getCountryName())
                                    .append(" - ")
                                    .append(dto.getCurrency());
                            this.countryRepository.saveAndFlush(country);
                        } else {
                            resultInfo.append("Invalid country");
                        }
                    } else {
                        resultInfo.append("Invalid country");
                    }
                    resultInfo.append(System.lineSeparator());
                });

        return resultInfo.toString().trim();
    }

    @Override
    public Country getCountryById(Long id) {
        return this.countryRepository.findById(id).orElse(null);
    }
}
