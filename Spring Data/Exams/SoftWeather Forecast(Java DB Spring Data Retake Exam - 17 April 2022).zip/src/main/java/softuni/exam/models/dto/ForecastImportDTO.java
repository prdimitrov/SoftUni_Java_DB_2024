package softuni.exam.models.dto;

import softuni.exam.models.entity.DayOfTheWeek;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import java.sql.Time;

@XmlAccessorType(XmlAccessType.FIELD)
public class ForecastImportDTO {
    @XmlElement(name = "day_of_week")
    private String dayOfWeek;
    @XmlElement(name = "max_temperature")
    private double maxTemperature;
    @XmlElement(name = "min_temperature")
    private double minTemperature;
    @XmlElement(name = "sunrise")
    private String sunrise;
    @XmlElement(name = "sunset")
    private String sunset;
    @XmlElement(name = "city")
    private Long city;

    public ForecastImportDTO() {
    }
    @NotNull()
    public String getDayOfWeek() {
        return dayOfWeek;
    }
    @NotNull
    @Min(-20)
    @Max(60)
    public double getMaxTemperature() {
        return maxTemperature;
    }
    @NotNull
    @Min(-50)
    @Max(40)
    public double getMinTemperature() {
        return minTemperature;
    }
    @NotNull
    public String getSunrise() {
        return sunrise;
    }
    @NotNull
    public String getSunset() {
        return sunset;
    }
    @NotNull
    public Long getCity() {
        return city;
    }
}
