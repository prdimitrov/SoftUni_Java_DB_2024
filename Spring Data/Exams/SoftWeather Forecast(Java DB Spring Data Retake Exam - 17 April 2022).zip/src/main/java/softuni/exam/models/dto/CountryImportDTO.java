package softuni.exam.models.dto;

import com.google.gson.annotations.Expose;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CountryImportDTO {
    @Expose
    private String countryName;
    @Expose
    private String currency;

    public CountryImportDTO() {
    }

    @NotNull
    @Size(min = 2, max = 60)
    public String getCountryName() {
        return countryName;
    }

    @NotNull
    @Size(min = 2, max = 40)
    public String getCurrency() {
        return currency;
    }
}
