package softuni.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import softuni.exam.models.entity.City;
import softuni.exam.models.entity.DayOfTheWeek;
import softuni.exam.models.entity.Forecast;

import java.util.List;

@Repository
public interface ForecastRepository extends JpaRepository<Forecast, Long> {

    Forecast findByDayOfWeekAndCity(DayOfTheWeek day, City cityId);
            /*
        Export Sunday forecast from Database
•	Extract from the database, the city name, min temperature (to the second digit after decimal point), max temperature (to the second digit after the decimal point), sunrise and sunset of the forecast.
•	Filter only forecasts from sunday and from cities with less than 150000 citizens, order them by max temperature in descending order, then by the forecast id in ascending order.
•	Return the information in this format:
•	"City: {cityName}:
   		-min temperature: {minTemperature}
   		--max temperature: {maxTemperature}
   		---sunrise: {sunrise}
----sunset: {sunset}
         */

    //    List<Forecast> findAllByDayOfWeekOrderByMax_TemperatureDescThenByIdAsc(DayOfTheWeek day);
    @Query("SELECT f FROM Forecast f WHERE f.dayOfWeek = :dayOfWeek ORDER BY f.maxTemperature DESC, f.id ASC")
    List<Forecast> findAllByDayOfWeekOrderByMaxTemperatureDescThenByIdAsc(DayOfTheWeek dayOfWeek);

}
