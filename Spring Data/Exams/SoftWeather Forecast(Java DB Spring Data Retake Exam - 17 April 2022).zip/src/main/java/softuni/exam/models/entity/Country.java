package softuni.exam.models.entity;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "countries")
public class Country extends BaseEntity {
    @Column(name = "country_name",
            unique = true,
            nullable = false)
    private String countryName;

    @Column(name = "currency", nullable = false)
    private String currency;

    @OneToMany(mappedBy = "country", cascade = CascadeType.MERGE)
    private Set<City> cities;

    public Country() {
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Set<City> getCities() {
        return cities;
    }

    public void setCities(Set<City> cities) {
        this.cities = cities;
    }
}
