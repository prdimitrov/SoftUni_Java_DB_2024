package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.ForecastImportRootDTO;
import softuni.exam.models.entity.DayOfTheWeek;
import softuni.exam.models.entity.Forecast;
import softuni.exam.repository.ForecastRepository;
import softuni.exam.service.CityService;
import softuni.exam.service.ForecastService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@Service
public class ForecastServiceImpl implements ForecastService {
    private static final String FORECASTS_FILE_PATH = "src/main/resources/files/xml/forecasts.xml";
    private final ForecastRepository forecastRepository;
    private final XmlParser xmlParser;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;
    private final CityService cityService;

    @Autowired
    public ForecastServiceImpl(ForecastRepository forecastRepository, XmlParser xmlParser, ValidationUtil validationUtil, ModelMapper modelMapper, CityService cityService) {
        this.forecastRepository = forecastRepository;
        this.xmlParser = xmlParser;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
        this.cityService = cityService;
    }

    @Override
    public boolean areImported() {
        return this.forecastRepository.count() > 0;
    }

    @Override
    public String readForecastsFromFile() throws IOException {
        return Files.readString(Path.of(FORECASTS_FILE_PATH));
    }

    @Override
    public String importForecasts() throws IOException, JAXBException {
        StringBuilder resultInfo = new StringBuilder();
        ForecastImportRootDTO dtos = this.xmlParser
                .parseXml(ForecastImportRootDTO.class, FORECASTS_FILE_PATH);

        dtos.getForecasts()
                .forEach(dto -> {
                    System.out.println();
                    if (this.validationUtil.isValid(dto)) {
                        boolean isValidDay = false;
                        for (DayOfTheWeek value : DayOfTheWeek.values()) {
                            if (value.name().equals(dto.getDayOfWeek())) {
                                isValidDay = true;
                                break;
                            }
                        }
                        if (!isValidDay) {
                            resultInfo.append("Invalid forecast")
                                    .append(System.lineSeparator());
                            return; // Skip further processing for this invalid forecast
                        }

                        DayOfTheWeek day = DayOfTheWeek.valueOf(dto.getDayOfWeek());
                        if (this.forecastRepository.findByDayOfWeekAndCity(day, this.cityService.getCityById(dto.getCity())) == null) {
                            Forecast forecast = this.modelMapper.map(dto, Forecast.class);
                            forecast.setCity(this.cityService.getCityById(dto.getCity()));
                            forecast.setDayOfWeek(day);

                            //Successfully import forecast FRIDAY - 25.00
                            resultInfo.append("Successfully import ")
                                    .append(dto.getDayOfWeek())
                                    .append(" - ")
                                    .append(String.format("%.2f", dto.getMaxTemperature()));
                            this.forecastRepository.saveAndFlush(forecast);
                        } else {
                            resultInfo.append("Invalid forecast");
                        }
                    } else {
                        resultInfo.append("Invalid forecast");
                    }
                    resultInfo.append(System.lineSeparator());
                });

        return resultInfo.toString().trim();
    }

    @Override
    public String exportForecasts() {
        StringBuilder results = new StringBuilder();
        List<Forecast> forecastList = this.forecastRepository.findAllByDayOfWeekOrderByMaxTemperatureDescThenByIdAsc(DayOfTheWeek.SUNDAY);
        System.out.println();
                /*
        Export Sunday forecast from Database
•	Extract from the database, the city name, min temperature (to the second digit after decimal point), max temperature (to the second digit after the decimal point), sunrise and sunset of the forecast.
•	Filter only forecasts from sunday and from cities with less than 150000 citizens, order them by max temperature in descending order, then by the forecast id in ascending order.
•	Return the information in this format:
•	"City: {cityName}:
   		-min temperature: {minTemperature}
   		--max temperature: {maxTemperature}
   		---sunrise: {sunrise}
----sunset: {sunset}
         */
        for (Forecast forecast : forecastList) {
            if (forecast.getCity().getPopulation() < 150000) {
                String forecastCity = forecast.getCity().getCityName();
                double minTemp = forecast.getMinTemperature();
                double maxTemp = forecast.getMaxTemperature();
                String sunrise = forecast.getSunrise().toString();
                String sunSet = forecast.getSunset().toString();
                String newLine = System.lineSeparator();
                results.append("City: ").append(forecastCity).append(newLine)
                        .append("-min temperature: ").append(String.format("%.2f", minTemp)).append(newLine)
                        .append("--max temperature: ").append(String.format("%.2f", maxTemp)).append(newLine)
                        .append("---sunrise: ").append(sunrise).append(newLine)
                        .append("----sunset: ").append(sunSet).append(newLine);
            }
        }
        return results.toString().trim();
    }
}
