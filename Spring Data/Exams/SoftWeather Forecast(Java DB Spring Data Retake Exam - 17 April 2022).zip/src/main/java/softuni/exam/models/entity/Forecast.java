package softuni.exam.models.entity;

import javax.persistence.*;
import java.sql.Time;

@Entity
@Table(name = "forecasts")
public class Forecast extends BaseEntity {

    @Column(name = "day_of_week",
            nullable = false)
    @Enumerated(EnumType.STRING)
    private DayOfTheWeek dayOfWeek;

    @Column(name = "max_temperature",
            nullable = false)
    private double maxTemperature;

    @Column(name = "min_temperature",
            nullable = false)
    private double minTemperature;

    @Column(name = "sunrise",
            nullable = false)
    private Time sunrise;

    @Column(name = "sunset",
            nullable = false)
    private Time sunset;

    @ManyToOne(targetEntity = City.class,
            fetch = FetchType.EAGER)
    private City city;

    public Forecast() {
    }

    public DayOfTheWeek getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(DayOfTheWeek dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public double getMaxTemperature() {
        return maxTemperature;
    }

    public void setMaxTemperature(double maxTemperature) {
        this.maxTemperature = maxTemperature;
    }

    public double getMinTemperature() {
        return minTemperature;
    }

    public void setMinTemperature(double minTemperature) {
        this.minTemperature = minTemperature;
    }

    public Time getSunrise() {
        return sunrise;
    }

    public void setSunrise(Time sunrise) {
        this.sunrise = sunrise;
    }

    public Time getSunset() {
        return sunset;
    }

    public void setSunset(Time sunset) {
        this.sunset = sunset;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }
}
